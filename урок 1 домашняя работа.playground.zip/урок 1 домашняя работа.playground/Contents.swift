import UIKit

var greeting = "Hello, playground"

// задание 1
let a = 10
let b = 9
var c = a + b
print(c)
